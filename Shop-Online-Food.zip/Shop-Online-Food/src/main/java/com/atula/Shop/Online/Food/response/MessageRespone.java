package com.atula.Shop.Online.Food.response;

import lombok.Data;

@Data
public class MessageRespone {
    private String message;

}
