package com.atula.Shop.Online.Food.config;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;

@Configuration
@EnableWebSecurity
public class AppConfig {
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{

            http.sessionManagement(management->management.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .authorizeHttpRequests(Authorize -> Authorize
                            .requestMatchers("/api/admin/**").hasAnyRole("RESTAURANT_OWNER","ADMIN")
                            .requestMatchers("/api/**").authenticated()
                            .anyRequest().permitAll()

                    ).addFilterBefore(new JwtTokenValidator(), BasicAuthenticationFilter.class) //Check header
                    .csrf(csrf->csrf.disable()) // Turn off sercurity (all permit allowed which not need token)
                    .cors(cors->cors.configurationSource(corsConfigurationSource())); // set info access

        return http.build();
    }

    private CorsConfigurationSource corsConfigurationSource() {

        return new CorsConfigurationSource() {
            @Override
            public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
                CorsConfiguration cfg = new CorsConfiguration();

                cfg.setAllowedOrigins(Arrays.asList(                    // link with another web
                        "http://atula-food.vercel.app",
                        "http://localhost:8080"
                ));
                cfg.setAllowedMethods(Collections.singletonList("*"));  // Allowed method get pust put dele
                cfg.setAllowCredentials(true);                          // Allow send request with cors. (cooki, header...)
                cfg.setAllowedHeaders(Collections.singletonList("*"));
                cfg.setExposedHeaders(Arrays.asList("Authorization"));  // After Cors submit, only header authorizztion disclosed to browser
                cfg.setMaxAge(3600L);                                   // Request max time 3600s

                return cfg;
            }
        };

    }
    @Bean
    PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

}
