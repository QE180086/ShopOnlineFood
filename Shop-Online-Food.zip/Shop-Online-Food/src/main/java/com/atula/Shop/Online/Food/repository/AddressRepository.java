package com.atula.Shop.Online.Food.repository;

import com.atula.Shop.Online.Food.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
