package com.atula.Shop.Online.Food.config;

public class JwtConstant {

    public static final String SECRET_KEY="gdyegdywshfcsdvsbsfaqkejiohjotyhjmofmbdsnvsuivhsdbuyegfyu";
    public static final String JWT_HEADER="Authorization";
}
