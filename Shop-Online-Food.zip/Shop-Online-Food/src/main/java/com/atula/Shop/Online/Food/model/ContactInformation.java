package com.atula.Shop.Online.Food.model;

import lombok.Data;

@Data
public class ContactInformation {
    private String email;
    private  String moblie;
    private String twitter;
    private String instagram;

}
